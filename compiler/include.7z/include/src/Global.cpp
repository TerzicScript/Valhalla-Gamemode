#include "Global.h"

namespace Global
{
    BOOL disableSyncBugs = true;
    BOOL knifeSync = true;
};