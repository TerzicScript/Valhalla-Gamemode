#!/bin/bash
make
cpack